// Import React hooks for state management and side effects
const { useState, useEffect } = React;

// Define news sources with their RSS feed URLs
const newspapers = {
  English: [
    { name: "The Times of India", url: "https://timesofindia.indiatimes.com/rssfeedstopstories.cms" },
    { name: "The Hindu", url: "https://www.thehindu.com/news/feeder/default.rss" },
    { name: "Hindustan Times", url: "https://www.hindustantimes.com/feeds/rss/india-news/rssfeed.xml" }
  ],
  Hindi: [
    { name: "Dainik Bhaskar", url: "https://www.bhaskar.com/rss-feed/2322/" },
    { name: "Amar Ujala", url: "https://www.amarujala.com/rss/india-news.xml" },
    { name: "Navbharat Times", url: "https://navbharattimes.indiatimes.com/rssfeeds/7098551.cms" }
  ]
};

// Main application component
function App() {
  // State variables
  const [headlines, setHeadlines] = useState({});
  const [search, setSearch] = useState("");
  const [tasks, setTasks] = useState(
    JSON.parse(localStorage.getItem("tasks") || "[]")
  );
  const [newTask, setNewTask] = useState("");
  const [loading, setLoading] = useState(true);

  // Fetch news headlines from RSS feeds
  useEffect(() => {
    const fetchHeadlines = async () => {
      setLoading(true);
      let updatedHeadlines = {};

      for (const language in newspapers) {
        updatedHeadlines[language] = [];
        for (const paper of newspapers[language]) {
          try {
            // Use server API to fetch RSS feeds
            const response = await fetch(`/api/rss-feed?url=${encodeURIComponent(paper.url)}`);
            const data = await response.json();

            if (data.status === 'ok' && data.items) {
              updatedHeadlines[language].push({ 
                name: paper.name, 
                articles: data.items.slice(0, 5).map(item => ({
                  title: item.title,
                  link: item.link
                }))
              });
            } else {
              updatedHeadlines[language].push({
                name: paper.name,
                articles: [],
                error: "Unable to fetch news"
              });
            }
          } catch (error) {
            console.error("Error fetching headlines:", error);
            updatedHeadlines[language].push({
              name: paper.name,
              articles: [],
              error: "Unable to fetch news"
            });
          }
        }
      }

      setHeadlines(updatedHeadlines);
      setLoading(false);
    };

    fetchHeadlines();
    // Refresh headlines every 5 minutes
    const interval = setInterval(fetchHeadlines, 300000);
    return () => clearInterval(interval);
  }, []);

  // Save tasks to localStorage
  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  // Task management functions
  const addTask = () => {
    if (newTask.trim() !== "") {
      setTasks([...tasks, { text: newTask, completed: false }]);
      setNewTask("");
    }
  };

  const toggleTask = (index) => {
    setTasks(tasks.map((task, i) => 
      i === index ? { ...task, completed: !task.completed } : task
    ));
  };

  const removeTask = (index) => {
    setTasks(tasks.filter((_, i) => i !== index));
  };

  // Loading indicator
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-center text-4xl font-bold mb-8">📰 QUICK PRESS</h1>
      
      {/* Search bar */}
      <input
        className="w-full p-3 rounded-lg mb-6 border border-gray-300"
        type="text"
        placeholder="🔍 Search headlines..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />
      
      {/* News sections by language */}
      {Object.keys(headlines).map((language) => (
        <div key={language} className="mb-8">
          <h2 className="text-2xl font-bold mb-4">{language}</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {headlines[language].map((paper, index) => (
              <div key={index} className="bg-white p-5 rounded-lg shadow-lg">
                <h3 className="text-lg font-semibold mb-3 text-blue-600">{paper.name}</h3>
                {paper.error ? (
                  <div className="text-red-500">{paper.error}</div>
                ) : (
                  <ul className="space-y-2">
                    {paper.articles
                      .filter((article) => 
                        article.title.toLowerCase().includes(search.toLowerCase())
                      )
                      .map((article, idx) => (
                        <li key={idx}>
                          <a 
                            href={article.link} 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="text-blue-500 hover:text-blue-700"
                          >
                            {idx + 1}. {article.title}
                          </a>
                        </li>
                      ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}
      
      {/* To-do list section */}
      <div className="mt-10 bg-white p-6 rounded-lg shadow-lg">
        <h2 className="text-2xl font-bold mb-4">📝 To-Do List</h2>
        <div className="flex gap-3 mb-4">
          <input
            className="flex-1 p-3 rounded-lg border border-gray-300"
            type="text"
            placeholder="Add a new task..."
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addTask()}
          />
          <button 
            className="bg-blue-600 text-white px-4 py-2 rounded-lg"
            onClick={addTask}
          >
            Add
          </button>
        </div>
        <ul className="space-y-2">
          {tasks.map((task, index) => (
            <li key={index} className={`p-3 rounded-lg flex justify-between items-center ${task.completed ? 'bg-green-600 text-white' : 'bg-gray-100'}`}>
              <div className="flex items-center gap-3">
                <input 
                  type="checkbox" 
                  checked={task.completed} 
                  onChange={() => toggleTask(index)}
                />
                <span 
                  onClick={() => toggleTask(index)} 
                  className={`cursor-pointer ${task.completed ? "line-through" : ""}`}
                >
                  {task.text}
                </span>
              </div>
              <button 
                className="bg-red-500 text-white px-3 py-1 rounded"
                onClick={() => removeTask(index)}
              >
                Delete
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

// Render the App component to the DOM
ReactDOM.render(<App />, document.getElementById('root'));