// Define React components
const { useState, useEffect } = React;

// Define newspaper sources
const newspapers = {
  English: [
    { name: "The Times of India", url: "https://timesofindia.indiatimes.com/rssfeedstopstories.cms" },
    { name: "The Hindu", url: "https://www.thehindu.com/news/feeder/default.rss" },
    { name: "Hindustan Times", url: "https://www.hindustantimes.com/feeds/rss/india-news/rssfeed.xml" },
    { name: "Indian Express", url: "https://indianexpress.com/feed/" }
  ],
  Hindi: [
    { name: "Dainik Bhaskar", url: "https://www.bhaskar.com/rss-feed/2322/" },
    { name: "Amar Ujala", url: "https://www.amarujala.com/rss/india-news.xml" },
    { name: "Dainik Jagran", url: "https://www.jagran.com/rss/news/national.xml" },
    { name: "Navbharat Times", url: "https://navbharattimes.indiatimes.com/rssfeeds/7098551.cms" }
  ]
};

// Task component
const Task = ({ task, index, toggleTask, removeTask }) => {
  return (
    <li className={`task-item ${task.completed ? 'completed bg-green-600' : 'bg-gray-200 dark:bg-gray-800'}`}>
      <div className="flex items-center">
        <input 
          type="checkbox" 
          checked={task.completed} 
          onChange={() => toggleTask(index)} 
          className="task-checkbox w-5 h-5"
        />
        <span 
          onClick={() => toggleTask(index)} 
          className={`task-text ml-3 ${task.completed ? 'completed' : ''}`}
        >
          {task.text}
        </span>
      </div>
      <button 
        onClick={() => removeTask(index)} 
        className="btn btn-danger text-sm"
      >
        Delete
      </button>
    </li>
  );
};

// Newspaper component
const NewspaperCard = ({ paper, search }) => {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchNews = async () => {
      try {
        setLoading(true);
        const response = await fetch(`/api/news?url=${encodeURIComponent(paper.url)}`);
        const data = await response.json();
        
        if (data.status === 'ok' && data.items) {
          setArticles(data.items.slice(0, 5));
          setError(null);
        } else {
          setError('Unable to fetch news at this time');
        }
      } catch (err) {
        console.error('Error fetching news:', err);
        setError('Unable to fetch news at this time');
      } finally {
        setLoading(false);
      }
    };

    fetchNews();
  }, [paper.url]);

  return (
    <div className="card bg-white dark:bg-gray-800 p-5">
      <h3 className="newspaper-title text-lg">{paper.name}</h3>
      
      {loading && (
        <div className="text-center py-4">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        </div>
      )}
      
      {error && !loading && (
        <div className="flex items-center text-red-500">
          <svg className="w-5 h-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <p>{error}</p>
        </div>
      )}
      
      {!loading && !error && (
        <ul className="space-y-2">
          {articles
            .filter(article => article.title.toLowerCase().includes(search.toLowerCase()))
            .map((article, idx) => (
              <li key={idx} className="border-b border-gray-200 dark:border-gray-700 pb-2 mb-2 last:border-0 last:pb-0 last:mb-0">
                <a 
                  href={article.link} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="hover:text-blue-600 transition-colors"
                >
                  {idx + 1}. {article.title}
                </a>
              </li>
            ))}
        </ul>
      )}
    </div>
  );
};

// Main application component
const App = () => {
  const [search, setSearch] = useState("");
  const [tasks, setTasks] = useState(
    JSON.parse(localStorage.getItem("tasks") || "[]")
  );
  const [newTask, setNewTask] = useState("");

  // Save tasks to local storage when they change
  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  // Task management functions
  const addTask = () => {
    if (newTask.trim() !== "") {
      setTasks([...tasks, { text: newTask, completed: false }]);
      setNewTask("");
    }
  };

  const toggleTask = (index) => {
    setTasks(tasks.map((task, i) => 
      i === index ? { ...task, completed: !task.completed } : task
    ));
  };

  const removeTask = (index) => {
    setTasks(tasks.filter((_, i) => i !== index));
  };

  // Handle Enter key for adding tasks
  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      addTask();
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="app-title text-4xl font-bold text-center mb-8">📰 QUICK PRESS</h1>
      
      {/* Search bar */}
      <div className="mb-8">
        <input
          type="text"
          placeholder="🔍 Search headlines..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="search-input dark:bg-gray-800 dark:text-white dark:border-gray-700"
        />
      </div>
      
      {/* News section */}
      {Object.keys(newspapers).map((language) => (
        <div key={language} className="mb-10">
          <h2 className="text-2xl font-bold mb-4 text-gray-800 dark:text-gray-200">{language} News</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {newspapers[language].map((paper, index) => (
              <NewspaperCard key={index} paper={paper} search={search} />
            ))}
          </div>
        </div>
      ))}
      
      {/* To-do list section */}
      <div className="mt-12 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
        <h2 className="text-2xl font-bold mb-6 text-gray-800 dark:text-gray-200">📝 To-Do List</h2>
        
        <div className="flex gap-4 mb-6">
          <input
            type="text"
            placeholder="Add a new task..."
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            onKeyPress={handleKeyPress}
            className="search-input flex-1 dark:bg-gray-700 dark:text-white dark:border-gray-600"
          />
          <button onClick={addTask} className="btn btn-primary">Add Task</button>
        </div>
        
        <ul className="space-y-3">
          {tasks.length === 0 ? (
            <p className="text-gray-500 dark:text-gray-400 text-center py-4">No tasks yet. Add some!</p>
          ) : (
            tasks.map((task, index) => (
              <Task 
                key={index} 
                task={task} 
                index={index} 
                toggleTask={toggleTask} 
                removeTask={removeTask} 
              />
            ))
          )}
        </ul>
      </div>
      
      <footer className="mt-12 text-center text-gray-600 dark:text-gray-400">
        <p>© {new Date().getFullYear()} QUICK PRESS - Indian News Aggregator</p>
      </footer>
    </div>
  );
};

// Render the application
ReactDOM.render(<App />, document.getElementById('root'));