# QUICK PRESS - Indian News Aggregator

A simple yet professional news aggregation application that provides the latest headlines from major Indian newspapers along with a useful to-do list feature.

## Project Overview

This application delivers news from major Indian newspapers in both English and Hindi languages, while also providing a to-do list to help users manage their tasks.

## Key Features

- **Live News Updates**: Fetches the latest headlines from major Indian news sources
- **Multilingual Support**: News in both English and Hindi
- **Search Functionality**: Filter headlines instantly
- **Task Management**: Add, complete, and delete to-do items
- **Persistent Storage**: Tasks are saved between sessions

## Files

This project is kept intentionally simple with just 3 essential files:

1. **index.html** - The main HTML page with minimal styling
2. **app.js** - The React application code for news display and task management
3. **server.js** - Backend server handling RSS feed fetching and caching

## Technology Used

- **Frontend**: React.js with Tailwind CSS
- **Backend**: Node.js with Express
- **Data Processing**: RSS Parser for fetching news
- **Storage**: Local storage for to-do items, server caching for news feeds

## How It Works

1. The server fetches RSS feeds from various Indian newspapers
2. Headlines are displayed in a clean, responsive grid layout
3. Users can search through the headlines
4. The to-do list feature allows users to track tasks independently

## How to Run

1. Install the required packages:
   ```
   npm install express rss-parser
   ```

2. Start the server:
   ```
   node server.js
   ```

3. Open in your browser:
   ```
   http://localhost:5000
   ```