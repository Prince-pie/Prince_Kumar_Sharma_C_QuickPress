/**
 * Quick Press - News Aggregator - Launcher Script
 * ------------------------------------------------
 * This script starts the News Aggregator application server.
 * It provides helpful messages and error handling.
 */

// Import the server module
require('./server');

console.log('=================================================');
console.log('  QUICK PRESS - News Aggregator');
console.log('  A professional news aggregation platform');
console.log('=================================================');
console.log('');
console.log('Server started successfully!');
console.log('Open your browser at: http://localhost:5000');
console.log('');
console.log('Press Ctrl+C to stop the server');