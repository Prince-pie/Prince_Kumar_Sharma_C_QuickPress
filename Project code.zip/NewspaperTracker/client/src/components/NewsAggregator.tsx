import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type Newspaper = {
  name: string;
  url: string;
};

type Article = {
  title: string;
  link: string;
};

type NewspaperData = {
  name: string;
  articles: Article[];
  error?: string;
};

type Task = {
  text: string;
  completed: boolean;
};

const newspapers: Record<'English' | 'Hindi', Newspaper[]> = {
  English: [
    { name: "The Times of India", url: "https://timesofindia.indiatimes.com/rssfeedstopstories.cms" },
    { name: "The Hindu", url: "https://www.thehindu.com/news/feeder/default.rss" },
    { name: "Hindustan Times", url: "https://www.hindustantimes.com/feeds/rss/india-news/rssfeed.xml" },
    { name: "Indian Express", url: "https://indianexpress.com/feed/" }
  ],
  Hindi: [
    { name: "Dainik Bhaskar", url: "https://www.bhaskar.com/rss-feed/2322/" },
    { name: "Amar Ujala", url: "https://www.amarujala.com/rss/india-news.xml" },
    { name: "Dainik Jagran", url: "https://www.jagran.com/rss/news/national.xml" },
    { name: "Navbharat Times", url: "https://navbharattimes.indiatimes.com/rssfeeds/7098551.cms" }
  ]
};

export function NewsAggregator() {
  const [headlines, setHeadlines] = useState<Record<string, NewspaperData[]>>({});
  const [search, setSearch] = useState("");
  const [tasks, setTasks] = useState<Task[]>(
    JSON.parse(localStorage.getItem("tasks") || "[]")
  );
  const [newTask, setNewTask] = useState("");
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    const fetchHeadlines = async () => {
      setLoading(true);
      let updatedHeadlines: Record<string, NewspaperData[]> = {};

      for (const language of Object.keys(newspapers) as Array<keyof typeof newspapers>) {
        updatedHeadlines[language] = [];
        for (const paper of newspapers[language]) {
          try {
            // Use our backend API instead of directly calling rss2json
            const response = await fetch(`/api/rss-feed?url=${encodeURIComponent(paper.url)}`);
            const data = await response.json();

            if (data.status === 'ok' && data.items) {
              updatedHeadlines[language].push({ 
                name: paper.name, 
                articles: data.items.slice(0, 5).map((item: any) => ({
                  title: item.title,
                  link: item.link
                }))
              });
            } else {
              updatedHeadlines[language].push({
                name: paper.name,
                articles: [],
                error: "Unable to fetch news at this time"
              });
              toast({
                title: "Warning",
                description: `Unable to fetch news from ${paper.name}. Please try again later.`,
                variant: "destructive"
              });
            }
          } catch (error) {
            console.error("Error fetching headlines for", paper.name, error);
            updatedHeadlines[language].push({
              name: paper.name,
              articles: [],
              error: "Unable to fetch news at this time"
            });
            toast({
              title: "Error",
              description: `Failed to fetch headlines from ${paper.name}`,
              variant: "destructive"
            });
          }
        }
      }

      setHeadlines(updatedHeadlines);
      setLoading(false);
    };

    fetchHeadlines();
    // Refresh headlines every 5 minutes
    const interval = setInterval(fetchHeadlines, 300000);
    return () => clearInterval(interval);
  }, [toast]);

  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  const addTask = () => {
    if (newTask.trim() !== "") {
      setTasks([...tasks, { text: newTask, completed: false }]);
      setNewTask("");
    }
  };

  const toggleTask = (index: number) => {
    setTasks(tasks.map((task, i) => i === index ? { ...task, completed: !task.completed } : task));
  };

  const removeTask = (index: number) => {
    setTasks(tasks.filter((_, i) => i !== index));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6">
      <h1 className="text-center text-3xl font-bold mb-6">📰 QUICK PRESS</h1>

      <Input
        className="w-full mb-6"
        type="text"
        placeholder="🔍 Search headlines..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      {Object.keys(headlines).map((language) => (
        <div key={language} className="mb-8">
          <h2 className="text-xl font-semibold mb-4">{language}</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {headlines[language].map((paper, index) => (
              <Card key={index} className="p-5">
                <h3 className="text-lg font-semibold mb-3">{paper.name}</h3>
                {paper.error ? (
                  <div className="flex items-center gap-2 text-destructive">
                    <AlertCircle className="h-4 w-4" />
                    <p>{paper.error}</p>
                  </div>
                ) : (
                  <ul className="space-y-2">
                    {paper.articles
                      .filter((article) => 
                        article.title.toLowerCase().includes(search.toLowerCase())
                      )
                      .map((article, idx) => (
                        <li key={idx}>
                          <a 
                            href={article.link} 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="text-blue-400 hover:text-blue-300 transition"
                          >
                            {idx + 1}. {article.title}
                          </a>
                        </li>
                      ))}
                  </ul>
                )}
              </Card>
            ))}
          </div>
        </div>
      ))}

      <div className="mt-10">
        <h2 className="text-2xl font-semibold mb-4">📝 To-Do List</h2>
        <div className="flex gap-3 mb-4">
          <Input
            type="text"
            placeholder="Add a new task..."
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addTask()}
          />
          <Button onClick={addTask}>Add</Button>
        </div>
        <ul className="space-y-2">
          {tasks.map((task, index) => (
            <li key={index} className={`p-3 rounded-lg flex justify-between items-center transition ${task.completed ? 'bg-green-600' : 'bg-secondary'}`}>
              <div className="flex items-center gap-3">
                <Checkbox 
                  checked={task.completed} 
                  onCheckedChange={() => toggleTask(index)}
                />
                <span 
                  onClick={() => toggleTask(index)} 
                  className={`cursor-pointer ${task.completed ? "line-through" : ""}`}
                >
                  {task.text}
                </span>
              </div>
              <Button 
                variant="destructive" 
                onClick={() => removeTask(index)}
              >
                Delete
              </Button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}