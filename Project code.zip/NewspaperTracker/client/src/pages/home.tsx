import { NewsAggregator } from "@/components/NewsAggregator";

export default function Home() {
  return <NewsAggregator />;
}