// Import required modules
import express from 'express';
import Parser from 'rss-parser';
import { fileURLToPath } from 'url';
import path from 'path';

// Get directory name in ES module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create Express application
const app = express();
const PORT = process.env.PORT || 5000;

// Create RSS parser instance
const parser = new Parser();

// Simple in-memory cache for RSS feeds
const cache = {};
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

// Serve static files from the current directory
app.use(express.static(__dirname));

// API endpoint to fetch RSS feeds
app.get('/api/news', async (req, res) => {
  try {
    const { url } = req.query;
    
    if (!url) {
      return res.status(400).json({ error: 'URL parameter is required' });
    }
    
    // Check cache first
    const now = Date.now();
    if (cache[url] && now - cache[url].timestamp < CACHE_TTL) {
      return res.json(cache[url].data);
    }
    
    // Fetch and parse the RSS feed
    const feed = await parser.parseURL(url);
    
    // Format the response
    const response = {
      status: 'ok',
      source: url,
      items: feed.items.map(item => ({
        title: item.title || '',
        link: item.link || '',
        pubDate: item.pubDate || '',
        content: item.content || item.contentSnippet || ''
      }))
    };
    
    // Cache the result
    cache[url] = {
      data: response,
      timestamp: now
    };
    
    res.json(response);
  } catch (error) {
    console.error('Error fetching RSS feed:', error);
    res.status(500).json({ 
      status: 'error', 
      error: 'Failed to fetch or parse the RSS feed' 
    });
  }
});

// Serve the main HTML file for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});