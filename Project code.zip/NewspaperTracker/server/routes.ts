import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import Parser from "rss-parser";

// Create RSS parser instance
const parser = new Parser();

// Cache mechanism to prevent frequent requests to news sources
const cache: {
  [key: string]: {
    data: any;
    timestamp: number;
  };
} = {};

// Cache validity period (5 minutes)
const CACHE_TTL = 5 * 60 * 1000;

export function registerRoutes(app: Express): Server {
  // RSS feed proxy endpoint
  app.get("/api/rss-feed", async (req: Request, res: Response) => {
    try {
      const url = req.query.url as string;
      
      if (!url) {
        return res.status(400).json({ error: "URL parameter is required" });
      }
      
      // Check if we have valid cached data
      const now = Date.now();
      if (cache[url] && now - cache[url].timestamp < CACHE_TTL) {
        return res.json(cache[url].data);
      }
      
      // Fetch and parse the RSS feed
      const feed = await parser.parseURL(url);
      
      // Format the response
      const response = {
        status: "ok",
        source: url,
        items: feed.items.map(item => ({
          title: item.title || "",
          link: item.link || "",
          pubDate: item.pubDate || "",
          content: item.content || item.contentSnippet || ""
        }))
      };
      
      // Cache the result
      cache[url] = {
        data: response,
        timestamp: now
      };
      
      res.json(response);
    } catch (error) {
      console.error("Error fetching RSS feed:", error);
      res.status(500).json({ 
        status: "error", 
        error: "Failed to fetch or parse the RSS feed" 
      });
    }
  });

  // Serve our simplified news aggregator app
  app.get("/quick-press", (req: Request, res: Response) => {
    res.sendFile("quick-press.html", { root: "." });
  });

  const httpServer = createServer(app);
  return httpServer;
}
