/**
 * QUICK PRESS - News Aggregator
 * A professional news aggregation application focusing on Indian news sources
 * with RSS feed integration and a companion to-do list functionality.
 */

// ===============================
// SERVER-SIDE CODE
// ===============================

/**
 * server.js - Main server file
 * Handles all backend operations including RSS feed fetching and parsing
 */
const express = require('express');
const Parser = require('rss-parser');
const path = require('path');

// Create Express application
const app = express();
const PORT = process.env.PORT || 5000;

// Create RSS parser instance
const parser = new Parser();

// Simple in-memory cache for RSS feeds
const cache = {};
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// API endpoint to fetch RSS feeds
app.get('/api/news', async (req, res) => {
  try {
    const { url } = req.query;
    
    if (!url) {
      return res.status(400).json({ error: 'URL parameter is required' });
    }
    
    // Check cache first
    const now = Date.now();
    if (cache[url] && now - cache[url].timestamp < CACHE_TTL) {
      return res.json(cache[url].data);
    }
    
    // Fetch and parse the RSS feed
    const feed = await parser.parseURL(url);
    
    // Format the response
    const response = {
      status: 'ok',
      source: url,
      items: feed.items.map(item => ({
        title: item.title || '',
        link: item.link || '',
        pubDate: item.pubDate || '',
        content: item.content || item.contentSnippet || ''
      }))
    };
    
    // Cache the result
    cache[url] = {
      data: response,
      timestamp: now
    };
    
    res.json(response);
  } catch (error) {
    console.error('Error fetching RSS feed:', error);
    res.status(500).json({ 
      status: 'error', 
      error: 'Failed to fetch or parse the RSS feed' 
    });
  }
});

// Serve the main HTML file for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});


// ===============================
// CLIENT-SIDE CODE
// ===============================

/**
 * app.js - Frontend React application
 * Handles the user interface and interactions
 */

// Define newspaper sources with their RSS feed URLs
const newspapers = {
  English: [
    { name: "The Times of India", url: "https://timesofindia.indiatimes.com/rssfeedstopstories.cms" },
    { name: "The Hindu", url: "https://www.thehindu.com/news/feeder/default.rss" },
    { name: "Hindustan Times", url: "https://www.hindustantimes.com/feeds/rss/india-news/rssfeed.xml" },
    { name: "Indian Express", url: "https://indianexpress.com/feed/" }
  ],
  Hindi: [
    { name: "Dainik Bhaskar", url: "https://www.bhaskar.com/rss-feed/2322/" },
    { name: "Amar Ujala", url: "https://www.amarujala.com/rss/india-news.xml" },
    { name: "Dainik Jagran", url: "https://www.jagran.com/rss/news/national.xml" },
    { name: "Navbharat Times", url: "https://navbharattimes.indiatimes.com/rssfeeds/7098551.cms" }
  ]
};

// Main Application Component
function NewsAggregatorApp() {
  const [headlines, setHeadlines] = React.useState({});
  const [search, setSearch] = React.useState("");
  const [tasks, setTasks] = React.useState(
    JSON.parse(localStorage.getItem("tasks") || "[]")
  );
  const [newTask, setNewTask] = React.useState("");
  const [loading, setLoading] = React.useState(true);

  // Fetch headlines from all newspapers when component mounts
  React.useEffect(() => {
    const fetchHeadlines = async () => {
      setLoading(true);
      let updatedHeadlines = {};

      for (const language in newspapers) {
        updatedHeadlines[language] = [];
        for (const paper of newspapers[language]) {
          try {
            // Use our backend API to fetch RSS feeds
            const response = await fetch(`/api/news?url=${encodeURIComponent(paper.url)}`);
            const data = await response.json();

            if (data.status === 'ok' && data.items) {
              updatedHeadlines[language].push({ 
                name: paper.name, 
                articles: data.items.slice(0, 5).map(item => ({
                  title: item.title,
                  link: item.link
                }))
              });
            } else {
              updatedHeadlines[language].push({
                name: paper.name,
                articles: [],
                error: "Unable to fetch news at this time"
              });
            }
          } catch (error) {
            console.error("Error fetching headlines for", paper.name, error);
            updatedHeadlines[language].push({
              name: paper.name,
              articles: [],
              error: "Unable to fetch news at this time"
            });
          }
        }
      }

      setHeadlines(updatedHeadlines);
      setLoading(false);
    };

    fetchHeadlines();
    // Refresh headlines every 5 minutes
    const interval = setInterval(fetchHeadlines, 300000);
    return () => clearInterval(interval);
  }, []);

  // Persist tasks to localStorage whenever they change
  React.useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  // Task management functions
  const addTask = () => {
    if (newTask.trim() !== "") {
      setTasks([...tasks, { text: newTask, completed: false }]);
      setNewTask("");
    }
  };

  const toggleTask = (index) => {
    setTasks(tasks.map((task, i) => 
      i === index ? { ...task, completed: !task.completed } : task
    ));
  };

  const removeTask = (index) => {
    setTasks(tasks.filter((_, i) => i !== index));
  };

  // Loading indicator
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6">
      <h1 className="text-center text-3xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
        📰 QUICK PRESS
      </h1>

      {/* Search input */}
      <input
        className="w-full p-3 rounded-lg mb-6 border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        type="text"
        placeholder="🔍 Search headlines..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      {/* News sections by language */}
      {Object.keys(headlines).map((language) => (
        <div key={language} className="mb-8">
          <h2 className="text-xl font-semibold mb-4">{language}</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {headlines[language].map((paper, index) => (
              <div key={index} className="bg-white dark:bg-gray-800 p-5 rounded-lg shadow-lg">
                <h3 className="text-lg font-semibold mb-3 text-blue-600">{paper.name}</h3>
                {paper.error ? (
                  <div className="flex items-center gap-2 text-red-500">
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <p>{paper.error}</p>
                  </div>
                ) : (
                  <ul className="space-y-2">
                    {paper.articles
                      .filter((article) => 
                        article.title.toLowerCase().includes(search.toLowerCase())
                      )
                      .map((article, idx) => (
                        <li key={idx} className="border-b border-gray-200 pb-2 last:border-0">
                          <a 
                            href={article.link} 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="text-blue-500 hover:text-blue-700 transition"
                          >
                            {idx + 1}. {article.title}
                          </a>
                        </li>
                      ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}

      {/* To-do list section */}
      <div className="mt-10 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg">
        <h2 className="text-2xl font-semibold mb-4">📝 To-Do List</h2>
        <div className="flex gap-3 mb-4">
          <input
            className="flex-1 p-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500"
            type="text"
            placeholder="Add a new task..."
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addTask()}
          />
          <button 
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition"
            onClick={addTask}
          >
            Add
          </button>
        </div>
        <ul className="space-y-2">
          {tasks.map((task, index) => (
            <li key={index} className={`p-3 rounded-lg flex justify-between items-center transition ${task.completed ? 'bg-green-600 text-white' : 'bg-gray-100 dark:bg-gray-700'}`}>
              <div className="flex items-center gap-3">
                <input 
                  type="checkbox" 
                  checked={task.completed} 
                  onChange={() => toggleTask(index)}
                  className="form-checkbox h-5 w-5 text-blue-600"
                />
                <span 
                  onClick={() => toggleTask(index)} 
                  className={`cursor-pointer ${task.completed ? "line-through" : ""}`}
                >
                  {task.text}
                </span>
              </div>
              <button 
                className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded transition"
                onClick={() => removeTask(index)}
              >
                Delete
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

// Render the application
ReactDOM.render(<NewsAggregatorApp />, document.getElementById('root'));


// ===============================
// HTML TEMPLATE
// ===============================

/**
 * index.html - Main HTML template
 */
/*
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>QUICK PRESS - News Aggregator</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f9fafb;
    }
    
    .dark body {
      background-color: #1a202c;
      color: #f8f9fa;
    }
    
    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div id="root"></div>
  <script src="https://unpkg.com/react@17/umd/react.development.js"></script>
  <script src="https://unpkg.com/react-dom@17/umd/react-dom.development.js"></script>
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
  <script type="text/babel" src="app.js"></script>
</body>
</html>
*/